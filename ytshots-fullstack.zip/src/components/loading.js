import React from 'react'

const Loading = () => {
    return (
        <div>
           <div class="loader">Loading...</div>
        </div>
    )
}

export default Loading