import React, {Fragment} from 'react';

export default function Footer (props) {
  return (
    <Fragment>
      <p><strong>© Shortsloader.Com</strong></p>
      <br/>
    </Fragment>
    )
}